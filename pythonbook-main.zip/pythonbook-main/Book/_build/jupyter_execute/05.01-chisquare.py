(chisquare)=
# Categorical data analysis

